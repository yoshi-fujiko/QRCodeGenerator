$(".appDl").on("click", function() {
	ga('send', 'event', 'ios_app', 'appDLSite', {'nonInteraction' : 1});
});